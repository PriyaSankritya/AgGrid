import { Component, OnInit } from '@angular/core';
import { ColDef, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {


  colmDfs: any;
  gridApi: any;
  gridColumnApi: any;
  sortingOrd: any;

  constructor(private http: HttpClient) { }
  
  ngOnInit(): void {
    this.colmDfs = [
      
      { field: 'athlete', maintainColumnOrder: true },
      { field: 'age', sortable: true, filter: true, maintainColumnOrder: true },
      { field: 'country', sortable: true, filter: true },
      { field: 'sport', sortable: true, filter: true },
      { field: 'year', sortable: true, filter: true },
      { field: 'date', sortable: true, filter: true },
      { field: 'gold', sortable: true, filter: true },
      { field: 'silver', sortable: true, filter: true },
      { field: 'bronze', sortable: true, filter: true },
      { field: 'total', sortable: true, filter: true },

    ]

  }

  onColumnMoved(params: any) {
    var columnState = JSON.stringify(params.columnApi.getColumnState());
    localStorage.setItem('myColumnState', columnState);
    console.log("All Column Headers: ", columnState);
    console.log("Headers: ", params);
    
  }

  onGridReady(params: any) {
    var columnState = JSON.parse(localStorage.getItem('myColumnState')!);
    if (columnState) {
      params.columnApi.setColumnState(columnState);
    }
    this.http.get<any[]>('https://www.ag-grid.com/example-assets/olympic-winners.json')
      .subscribe(data => {

        params.api.setRowData(data);
      });
  }
  getDta() {
    var rowNode = this.gridApi.getDisplayedRowAtIndex(0);
    alert(rowNode.data.athlete);
  }
}

function columnState(arg0: string, columnState: any) {
  throw new Error('Function not implemented.');
}

